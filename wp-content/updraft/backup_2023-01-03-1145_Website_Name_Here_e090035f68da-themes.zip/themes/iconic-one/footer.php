</div><!-- #main .wrapper -->
</div><!-- #page -->
</div><!-- #page-wrap -->

<div id="footer"><div class="limit">
Footer goes here
</div></div>

<div id="bottom"><div class="limit">
	Website by <a rel="nofollow" title="Web Design & Development" href="https://goauroratech.com/">Aurora Tech</a>
</div></div>

<?php wp_footer(); ?>
</body>
</html>